# vbnet-sql-db-basicv1
This is my basic program made a couple of years ago in a programming course. I uploaded it without any modifications, because I will continue to work until I polish it. The app is made completeley from scratch, you can se the DER-Factura image. From there I began to build the relational data base, then the scripting in SQL Server and later on the VB .net program connecting everything.
Also it must be clear, that some of the code was tought to me, including the SQL Server script, so it is not entirely mine. Although in the VB code I made some modifications to make the classes work universally rather than work only on this project.
The scripting was typed entirely 1v1 with the teacher.
