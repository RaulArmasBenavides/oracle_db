-- Creacion de Base de datos

use master
if exists (select * from sys.databases where name='factura')
drop database factura

create database factura
go

use factura
go

-- Creacion de tablas

create table dbo.categoriaProducto
(
catCodigo int identity(1,1) not null,
catDescripcion varchar(200) not null,
primary key (catCodigo)
)
go

create table dbo.producto
(
proCodigo int identity(1,1) not null,
proDescripcion varchar(200) not null,
proPrecioCompra decimal(18,2) not null,
proPrecioVenta decimal(18,2) not null,
proFechaCompra date not null,
proFechaVencimiento date not null,
proExistencia int not null,
catCodigo int not null,
primary key (proCodigo),
foreign key (catCodigo) references dbo.categoriaProducto (catCodigo)
)
go

create table dbo.cliente
(
cliCodigo int identity(1,1) not null,
cliNombre varchar(100) not null,
cliApellido varchar(100),
cliDireccion varchar(200) not null,
cliTelefono varchar(8) not null,
cliIdentidad varchar(13) not null,
cliCorreo varchar(50) not null,
primary key (cliCodigo)
)
go

create table dbo.empleado
(
empCodigo int identity(1,1) not null,
empNombre varchar(100) not null,
empApellido varchar(100),
empDireccion varchar(200) not null,
empFechaIngreso date not null,
empPuesto varchar(100) not null,
empSueldo decimal (18,2),
primary key (empCodigo)
)
go

create table dbo.pago
(
pagCodigo int identity(1,1) not null,
pagDescripcion varchar(200) not null,
primary key (pagCodigo)
)
go

create table dbo.factura
(
facCodigo int identity(1,1) not null,
cliCodigo int not null,
empCodigo int not null,
pagCodigo int not null,
facFecha date,
primary key (facCodigo),
foreign key (cliCodigo) references dbo.cliente (cliCodigo),
foreign key (empCodigo) references dbo.empleado (empCodigo),
foreign key (pagCodigo) references dbo.pago (pagCodigo)
)
go

create table dbo.detalleFactura
(
facCodigo int not null,
proCodigo int not null,
dfaCantidad int not null,
primary key (facCodigo, proCodigo),
foreign key (facCodigo) references dbo.factura (facCodigo),
foreign key (proCodigo) references dbo.producto (proCodigo)
)
go

-- Creacion de procedimientos -- mostrar

create procedure sp_mCategoriaProducto
as
select * from dbo.categoriaProducto order by catCodigo desc
go

CREATE procedure sp_mProducto
as
select dbo.producto.proCodigo,
dbo.categoriaProducto.catCodigo,
dbo.producto.proDescripcion,
dbo.categoriaProducto.catDescripcion,
dbo.producto.proPrecioVenta,
dbo.producto.proPrecioCompra,
dbo.producto.proFechaCompra,
dbo.producto.proFechaVencimiento,
dbo.producto.proExistencia
from dbo.producto inner join dbo.categoriaProducto on
dbo.producto.catCodigo = dbo.categoriaProducto.catCodigo
order by dbo.producto.proCodigo desc
GO

create procedure sp_mCliente
as
select * from dbo.cliente order by cliCodigo desc
GO

create procedure sp_mEmpleado
as
select * from dbo.empleado order by empCodigo desc
GO

create procedure sp_mPago
as
select * from dbo.pago order by pagCodigo desc
GO

CREATE procedure sp_mFactura
as
SELECT dbo.factura.facCodigo,
dbo.factura.facFecha,
dbo.cliente.cliCodigo,
dbo.cliente.cliNombre,
dbo.cliente.cliApellido,
dbo.pago.pagCodigo,
dbo.pago.pagDescripcion,
dbo.empleado.empCodigo,
dbo.empleado.empNombre,
dbo.empleado.empPuesto
FROM dbo.factura INNER JOIN
dbo.cliente ON dbo.factura.cliCodigo = dbo.cliente.cliCodigo INNER JOIN
dbo.empleado ON dbo.factura.empCodigo = dbo.empleado.empCodigo INNER JOIN
dbo.pago ON dbo.factura.pagCodigo = dbo.pago.pagCodigo
order by dbo.factura.facCodigo desc
GO

CREATE procedure sp_mDetalleFactura
@facCodigo int
as
SELECT dbo.detalleFactura.facCodigo,
dbo.detalleFactura.proCodigo,
dbo.producto.proDescripcion,
dbo.categoriaProducto.catDescripcion,
dbo.producto.proPrecioVenta, 
dbo.detalleFactura.dfaCantidad,
dbo.producto.proFechaVencimiento,
(dbo.producto.proPrecioVenta*dbo.detalleFactura.dfaCantidad)as total,
dbo.producto.proExistencia 
FROM dbo.detalleFactura INNER JOIN
dbo.factura ON dbo.detalleFactura.facCodigo = dbo.factura.facCodigo INNER JOIN
dbo.producto ON dbo.detalleFactura.proCodigo = dbo.producto.proCodigo INNER JOIN
dbo.categoriaProducto ON dbo.producto.catCodigo = dbo.categoriaProducto.catCodigo
where dbo.factura.facCodigo = @facCodigo
GO

-- Creacion de procedimiento -- insertar

create procedure sp_iCategoriaProducto
@catDescripcion varchar(200)
as
insert into dbo.categoriaProducto
(catDescripcion)
values
(@catDescripcion)
go

create procedure sp_iProducto
@proDescripcion varchar(200),
@proPrecioCompra decimal(18,2),
@proPrecioVenta decimal(18,2),
@proFechaCompra date,
@proFechaVencimiento date,
@catCodigo int,
@proExistencia int
as insert into dbo.producto
(proDescripcion, proPrecioCompra, proPrecioVenta,
proFechaCompra, proFechaVencimiento, catCodigo, proExistencia)
values
(@proDescripcion, @proPrecioCompra, @proPrecioVenta,
@proFechaCompra, @proFechaVencimiento, @catCodigo, @proExistencia)
go

create procedure sp_iCliente
@cliNombre varchar(100),
@cliApellido varchar(100),
@cliDireccion varchar(200),
@cliTelefono varchar(8),
@cliIdentidad varchar(13),
@cliCorreo varchar(50)
as insert into dbo.cliente
(cliNombre,cliApellido,cliDireccion,cliTelefono,cliIdentidad,cliCorreo)
values 
(@cliNombre ,@cliApellido,@cliDireccion,@cliTelefono,@cliIdentidad,@cliCorreo)
GO

create procedure sp_iEmpleado
@empNombre varchar(100),
@empApellido varchar(100),
@empDireccion varchar(200),
@empFechaIngreso date,
@empPuesto varchar(100),
@empSueldo decimal (18,2)
as insert into dbo.empleado
(empNombre,empApellido,empDireccion,empFechaIngreso,empPuesto,empSueldo)
values
(@empNombre,@empApellido,@empDireccion,@empFechaIngreso,@empPuesto,@empSueldo)
GO

create procedure sp_iPago
@pagDescripcion varchar(200)
as insert into dbo.pago 
(pagDescripcion)
values
(@pagDescripcion)
GO

CREATE proc sp_iFactura
@clicodigo int,
@empcodigo int,
@pagcodigo int,
@facFecha date
as insert into dbo.factura
(cliCodigo, empCodigo, pagCodigo, facFecha)
values
(@cliCodigo, @empCodigo, @pagCodigo, @facFecha)
GO

create proc sp_iDetalleFactura
@facCodigo int,
@proCodigo int,
@dfaCantidad int
as insert into dbo.detalleFactura
(facCodigo,proCodigo,dfaCantidad)
values
(@facCodigo,@proCodigo,@dfaCantidad)
GO

-- Creacion de procedimiento -- actualizar

create procedure sp_aCategoriaProducto
@catCodigo int,
@catDescripcion varchar(200)
as
update dbo.categoriaProducto set
catDescripcion = @catDescripcion
where
catCodigo = @catCodigo
go

create procedure sp_aProducto
@proCodigo int,
@proDescripcion varchar(200),
@proPrecioCompra decimal(18,2),
@proPrecioVenta decimal(18,2),
@proFechaCompra date,
@proFechaVencimiento date,
@catCodigo int,
@proExistencia int
as
update dbo.producto set
proDescripcion=@proDescripcion,
 proPrecioCompra=@proPrecioCompra,
 proPrecioVenta=@proPrecioVenta,
 proFechaCompra=@proFechaCompra,
 proFechaVencimiento=@proFechaVencimiento,
 catCodigo=@catCodigo,
 proExistencia=@proExistencia
 where 
 proCodigo=@proCodigo
go

create procedure sp_aCliente
@cliCodigo int,
@cliNombre varchar(100),
@cliApellido varchar(100),
@cliDireccion varchar(200),
@cliTelefono varchar(8),
@cliIdentidad varchar(13),
@cliCorreo varchar(50)
as update dbo.cliente set
cliNombre=@cliNombre,
cliApellido=@cliApellido,
cliDireccion=@cliDireccion,
cliTelefono=@cliTelefono,
cliIdentidad=@cliIdentidad,
cliCorreo=@cliCorreo
where
cliCodigo=@cliCodigo
GO

create procedure sp_aEmpleado
@empCodigo int,
@empNombre varchar(100),
@empApellido varchar(100),
@empDireccion varchar(200),
@empFechaIngreso date,
@empPuesto varchar(100),
@empSueldo decimal (18,2)
as update dbo.empleado set
empNombre=@empNombre,
empApellido=@empApellido,
empDireccion=@empDireccion,
empFechaIngreso=@empFechaIngreso,
empPuesto=@empPuesto,
empSueldo=@empSueldo
where
empCodigo=@empCodigo
GO

create procedure sp_aPago
@pagCodigo int,
@pagDescripcion varchar(200)
as update dbo.pago set
pagDescripcion=@pagDescripcion
where
pagCodigo=@pagCodigo
GO

CREATE procedure sp_aFactura
@facCodigo int,
@clicodigo int,
@empcodigo int,
@pagcodigo int,
@facFecha date
as update dbo.factura set
cliCodigo=@cliCodigo,
empCodigo=@empCodigo,
pagCodigo=@pagCodigo,
facFecha=@facFecha
where facCodigo=@facCodigo
GO

create procedure sp_aDetalleFactura
@facCodigo int,
@proCodigo int,
@dfaCantidad int
as update dbo.detalleFactura set
dfaCantidad=@dfaCantidad
where facCodigo=@facCodigo and
proCodigo=@proCodigo
GO

-- Creacion procedimiento -- eliminar

create procedure sp_eCategoriaProducto
@catCodigo int
as
delete from dbo.categoriaProducto
where catCodigo=@catCodigo
go

create procedure sp_eCliente
@cliCodigo int
as delete from dbo.cliente
where cliCodigo=@cliCodigo
GO

create proc [dbo].[sp_eFactura]
@facCodigo int
as delete from dbo.factura
where facCodigo=@facCodigo
GO

create proc sp_eDetalleFactura
@facCodigo int,
@proCodigo int
as delete from dbo.detalleFactura
where facCodigo=@facCodigo and
proCodigo=@proCodigo
GO

-- Creacion procedimiento -- para reportes

CREATE procedure sp_rFactura
@facCodigo int
as
SELECT     dbo.factura.facCodigo,
dbo.cliente.cliNombre,
dbo.cliente.cliApellido,
dbo.cliente.cliDireccion,
dbo.cliente.cliTelefono,
dbo.empleado.empNombre,
dbo.empleado.empPuesto, 
dbo.pago.pagDescripcion,
dbo.producto.proDescripcion,
dbo.categoriaProducto.catDescripcion,
dbo.producto.proFechaVencimiento,
dbo.producto.proPrecioVenta, 
dbo.detalleFactura.dfaCantidad,
(dbo.producto.proPrecioVenta * dbo.detalleFactura.dfaCantidad) as total
FROM dbo.factura INNER JOIN
dbo.detalleFactura ON dbo.factura.facCodigo = dbo.detalleFactura.facCodigo INNER JOIN
dbo.cliente ON dbo.factura.cliCodigo = dbo.cliente.cliCodigo INNER JOIN
dbo.empleado ON dbo.factura.empCodigo = dbo.empleado.empCodigo INNER JOIN
dbo.pago ON dbo.factura.pagCodigo = dbo.pago.pagCodigo INNER JOIN
dbo.producto ON dbo.detalleFactura.proCodigo = dbo.producto.proCodigo INNER JOIN
dbo.categoriaProducto ON dbo.producto.catCodigo = dbo.categoriaProducto.catCodigo
where dbo.factura.facCodigo = @facCodigo
GO

-- Procedimiento de mantenimiento de productos x Compras / Ventas

create procedure sp_aumentoProducto
@proCodigo int,
@cantidad int
as update dbo.producto set proExistencia = proExistencia + @cantidad
where proCodigo = @proCodigo
go

create procedure sp_disminucionProducto
@proCodigo int,
@cantidad int
as
update dbo.producto set proExistencia = proExistencia - @cantidad
where proCodigo = @proCodigo
go


-- Inserccion de Datos

execute sp_iCategoriaProducto 'Verduras y Frutas'
execute sp_iCategoriaProducto 'Carnes'
execute sp_iCategoriaProducto 'Embutidos'
execute sp_iCategoriaProducto 'Lacteos'
execute sp_iCategoriaProducto 'Enlatados'
execute sp_iCategoriaProducto 'Refrescos'
execute sp_iCategoriaProducto 'Licores'

execute sp_iProducto 'Libra de tomate manzano','7.35', '9.55','05/18/2016','05/18/2016','1','10'
execute sp_iProducto 'Libra de papas','4.17', '8.00','11/05/2016','11/08/2016','1','10'
execute sp_iProducto 'Libra de Lomo de Res de exportacion','65.00', '98.00','10/05/2016','10/09/2016','2','10'

execute sp_iCliente 'Pedro','Hernandez','Colonia El Porvenir','22221515','0801195002310','pedro@gmail.com'
execute sp_iCliente 'Juan','Jimenez','Barrio La Esperanza','23331123','0801199602315','juan@gmail.com'
execute sp_iCliente 'Carlos','Lainez','Colonia El Bodegon','24441425','0801198602396','carlos@gmail.com'
execute sp_iCliente 'Fabricio','Hernandez','Colonia El Porvenir','22221515','0801194102336','fabricio@gmail.com'

execute sp_iEmpleado 'Carlos','Martinez','Colonia El Tablon','01/02/1980','cajero','7000.00'
execute sp_iEmpleado 'Ramiro','Rodriguez','Colonia El Porvenir','01/02/1980','carnicero','7000.00'
execute sp_iEmpleado 'Maria','Perez','Colonia El Porvenir','01/02/1980','supervisor','8500.00'

execute sp_iPago 'Efectivo'
execute sp_iPago 'Cheque'
execute sp_iPago 'Tarjeta de Credito'
execute sp_iPago 'Cupon'

