﻿Public Class eProducto
    Private proCodigo As Integer
    Private proDescripcion As String
    Private proPrecioCompra As Double
    Private proPrecioVenta As Double
    Private proFechaCompra As String
    Private proFechaVencimiento As String
    Private proExistencia As Decimal
    Private proCatCodigo As Integer


    Public Sub New()

    End Sub

    Public Sub New(pCodigo As Integer, pDescripcion As String, pPrecioCompra As Double, pPrecioVenta As Double, pFechaCompra As String,
                   pFechaVencimiento As String, pExistencia As Decimal, pCatCodigo As Integer)
        proCodigo = pCodigo
        proDescripcion = pDescripcion
        proPrecioCompra = pPrecioCompra
        proPrecioVenta = pPrecioVenta
        proFechaCompra = pFechaCompra
        proFechaVencimiento = pFechaVencimiento
        proExistencia = pExistencia
        proCatCodigo = pCatCodigo

    End Sub

    Public Property prCodigo
        Get
            Return proCodigo
        End Get
        Set(value)
            proCodigo = value
        End Set
    End Property

    Public Property prDescripcion
        Get
            Return proDescripcion

        End Get
        Set(value)
            proDescripcion = value

        End Set
    End Property

    Public Property prPrecioCompra
        Get
            Return proPrecioCompra

        End Get
        Set(value)
            proPrecioCompra = value

        End Set
    End Property

    Public Property prPrecioVenta
        Get
            Return proPrecioVenta

        End Get
        Set(value)
            proPrecioVenta = value
        End Set
    End Property

    Public Property prFechaCompra
        Get
            Return proPrecioVenta
        End Get
        Set(value)
            proPrecioVenta = value
        End Set
    End Property

    Public Property prFechaVencimiento
        Get
            Return proFechaVencimiento

        End Get
        Set(value)
            proFechaVencimiento = value
        End Set
    End Property

    Public Property prExistencia
        Get
            Return proExistencia

        End Get
        Set(value)
            proExistencia = value
        End Set
    End Property

    Public Property prCatCodigo
        Get
            Return proCatCodigo
        End Get
        Set(value)
            proCatCodigo = value
        End Set
    End Property
End Class
