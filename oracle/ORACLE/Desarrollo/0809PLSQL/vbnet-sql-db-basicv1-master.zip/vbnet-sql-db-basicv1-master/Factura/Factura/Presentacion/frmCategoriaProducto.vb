﻿'Formulario para mostrar, eliminar, actualizar e insertar datos.

Public Class frmCategoriaProducto
    Private dataTable As New DataTable
    Public bandera As New Boolean

    Private Sub frmCategoriaProducto_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbxBuscar.Items.Add("catDescripcion") 'Items que van a integrar al ComboBox
        cmbxBuscar.Text = ""
        txtCodigo.Enabled = False 'Desahibilitar modificacion de codigo.
        If (bandera) Then
            btnLimpiar.Enabled = False 'Desahibilitados solamente por estetica
            btnCancelar.Enabled = False
        Else
            btnLimpiar.Enabled = True 'Esteticamente deshabilitados
            btnCancelar.Enabled = True
        End If
        mostrar()
        limpiar()
    End Sub

    Private Sub mostrar() 'Muestra el formulario con los datos de la base de 
        Try
            Dim func As New fCategoriaProducto()
            dataTable = func.mostrar("sp_sCategoriaProducto")
            dgvDataListado.Columns.Item("eliminar").Visible = False 'Ocultar Eliminar en la columna

            If (dataTable.Rows.Count <> 0) Then 'Solamente si la tabla contiene informacion
                dgvDataListado.DataSource = dataTable 'Llenar el dataTable
                dgvDataListado.ColumnHeadersVisible = True
            Else 'Vacio
                dgvDataListado.DataSource = Nothing
                dgvDataListado.ColumnHeadersVisible = True 'Dejado TRUE por estetica 
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        txtBuscarXTexto()
    End Sub


    'dv.RowFilter = cmbBuscar.Text & txtBuscar.Text
    Private Sub txtBuscarXTexto()
        Try
            Dim dataSet As New DataSet 'Es una especie de colleccion de informacion de parecida al array de dos dimensiones. Contendra la tabla.
            dataSet.Tables.Add(dataTable.Copy) 'Pasamos los datos.
            Dim dataView As New DataView(dataSet.Tables(0)) 'Objeto para manipular dataView
            dataView.RowFilter = cmbxBuscar.Text & " like '" & txtBuscar.Text & "%'" 'preparamos un query, para que busque lo que escribamos, filtrando letra por letra

            If (dataView.Count <> 0) Then 'si no està vacìo
                dgvDataListado.DataSource = dataView  'dataGridView le asignamos que muestre lo buscado

            Else
                dgvDataListado.DataSource = Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    Private Sub ocultarcolumna()
        dgvDataListado.Columns(0).Visible = False
    End Sub


    Private Sub txtBuscar_TextChanged(sender As Object, e As EventArgs) Handles txtBuscar.TextChanged 'Busqueda cada vez que se cambia el texto
        mostrar()
    End Sub

    Private Sub limpiar()
        txtCodigo.Text = ""
        txtDescripcion.Text = ""
        txtBuscar.Text = ""
        cmbxBuscar.Text = "catDescripcion"
        txtDescripcion.Enabled = False
        btnActualizar.Enabled = False
        btnGuardar.Enabled = False
        btnEliminar.Enabled = False
        btnEditar.Enabled = False
        If (bandera) Then
            btnInsertar.Enabled = False
        Else
            btnInsertar.Enabled = True
        End If
    End Sub

    Private Sub btnCerrar_Click(sender As Object, e As EventArgs) Handles btnCerrar.Click
        Dim result As DialogResult

        result = MessageBox.Show("¿Desea cerrar la ventana? Se perderan datos.", "Cerrando...", MessageBoxButtons.OKCancel, MessageBoxIcon.Hand)
        If result = Windows.Forms.DialogResult.OK Then
            Me.Close()
        End If

    End Sub

    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
        limpiar()
    End Sub

    Private Sub btnInsertar_Click(sender As Object, e As EventArgs) Handles btnInsertar.Click
        limpiar()
        controlDesc(True)
        btnGuardar.Enabled = True
        btnInsertar.Enabled = False
        txtDescripcion.Focus()


    End Sub

    Private Sub controlDesc(value As Boolean)
        txtDescripcion.Enabled = value
    End Sub

    Private Sub edit()
        controlDesc(True)
    End Sub
    Private Sub btnGuardar_Click(sender As Object, e As EventArgs) Handles btnGuardar.Click
        If txtDescripcion.Text <> "" Then
            Try
                Dim eCatPro As New eCategoriaProducto
                eCatPro.pCatDescripcion = txtDescripcion.Text
                Dim funCatPro As New fCategoriaProducto(eCatPro)

                If funCatPro.insertar("sp_iCategoriaProducto") Then
                    MessageBox.Show("¡La categoria fue guardada exitosamente!", "Operacion exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    MessageBox.Show("Algo salio mal al guardar los datos. Intente de nuevo.", "Lo sentimos...", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                mostrar()
                limpiar()
            Catch ex As Exception
                MsgBox(ex.Message)


            End Try
        Else
            MessageBox.Show("Debe proporcionar una descripcion.", "Error: Descripcion.", MessageBoxButtons.OK, MessageBoxIcon.Error)


        End If
    End Sub


    Private Sub dgvDataListado_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvDataListado.CellClick
        traslado_informacion()
        If bandera Then
            btnActualizar.Enabled = False
            btnEditar.Enabled = False

        Else
            btnActualizar.Enabled = True
            btnEditar.Enabled = True

        End If
        btnInsertar.Enabled = False
        controlDesc(False)


    End Sub

    Private Sub traslado_informacion()
        txtCodigo.Text = dgvDataListado.SelectedCells.Item(1).Value
        txtDescripcion.Text = dgvDataListado.SelectedCells.Item(2).Value
    End Sub


    Private Sub btnActualizar_Click(sender As Object, e As EventArgs) Handles btnActualizar.Click
        If txtDescripcion.Text <> "" Then
            Dim resultado As DialogResult

            resultado = MessageBox.Show("¿Desea actualizar la categoria?", "Actualizando Categoria.", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
            If resultado = Windows.Forms.DialogResult.OK Then
                Try
                    Dim dts As New eCategoriaProducto
                    Dim func As New fCategoriaProducto
                    dts.pCatCodigo = txtCodigo.Text
                    dts.pCatDescripcion = txtDescripcion.Text
                    func.categ = dts
                    If func.actualizar("sp_iCategoriaProducto") Then
                        MessageBox.Show("La categoria fue actualizada correctamente!", "Operacion exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Else
                        MessageBox.Show("Algo salio mal al guardar los datos. Intente de nuevo", "Lo sentimos...", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try

            Else
                MessageBox.Show("La operacion ha sido cancelada", "Cancelado", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Else
            MessageBox.Show("Debe proporcionar una descripcion.", "Error: Descripcion", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        mostrar()
        limpiar()

    End Sub

    Private Sub ckbEliminar_CheckedChanged(sender As Object, e As EventArgs) Handles ckbEliminar.CheckedChanged
        If ckbEliminar.CheckState = CheckState.Checked Then
            dgvDataListado.Columns.Item("Eliminar").Visible = True
            btnEliminar.Visible = True
            btnInsertar.Enabled = False
            btnEliminar.Enabled = True


        Else
            dgvDataListado.Columns.Item("Eliminar").Visible = False
            btnEliminar.Visible = False
            btnInsertar.Enabled = True
        End If
    End Sub


    Private Sub dgvDataListado_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvDataListado.CellContentClick
        If e.ColumnIndex = Me.dgvDataListado.Columns.Item("Eliminar").Index Then
            Dim chkCell As DataGridViewCheckBoxCell = Me.dgvDataListado.Rows(e.RowIndex).Cells("Eliminar")
            chkCell.Value = Not chkCell.Value

        Else

        End If
    End Sub

    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        Dim resultado As DialogResult

        resultado = MessageBox.Show("¿Desea elimiar las selecciones?", "Eliminacion Registros", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
        If resultado = Windows.Forms.DialogResult.OK Then
            Try
                For Each row As DataGridViewRow In dgvDataListado.Rows
                    Dim chkLine As Boolean = Convert.ToBoolean(row.Cells("Eliminar").Value)
                    If chkLine Then
                        Dim primaryKey As Integer = Convert.ToInt16(row.Cells("catCodigo").Value)

                        Dim dts As New eCategoriaProducto
                        Dim fun As New fCategoriaProducto
                        dts.pCatCodigo = primaryKey
                        fun.categ = dts
                        If fun.eliminar("sp_dCategoriaProducto", dts.pCatCodigo) Then
                            MessageBox.Show("La categoria fue actualizada correctamente!", "Actualziado con exito!", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Else
                            MessageBox.Show("No se pudo eliminar la seleccion!", "Error al Eliminar!", MessageBoxButtons.OK, MessageBoxIcon.Error)


                        End If
                    Else

                    End If

                Next
                Call mostrar()
                Call limpiar()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        Else
            MessageBox.Show("Accion de eliminar cancelada", "Eliminar Cancelado", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub btnEditar_Click(sender As Object, e As EventArgs) Handles btnEditar.Click
        controlDesc(True)
    End Sub
End Class