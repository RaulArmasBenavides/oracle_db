﻿Public Class frmProducto

    Private Sub frmProducto_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub habilitar()
        'txtDescripcion.Enabled = True
        'txtPrecioCompra.Enabled = True
        'txtPrecioVenta.Enabled = True
        'txtCatDescripcion.Enabled = True
        'dtpFechaCompra.Enabled = True
        'dtpFechaVencimiento.Enabled = True
        'txtExistencia.Enabled = True
    End Sub

    'btnGuardar

End Class