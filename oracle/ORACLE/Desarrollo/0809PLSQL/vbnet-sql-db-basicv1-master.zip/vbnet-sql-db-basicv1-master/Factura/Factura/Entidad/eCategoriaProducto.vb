﻿'Esta es la clase de la que se haran objetos que corresponde a la entidad Categoria Producto en VB.
'Contiene las propiedades basicas de Categoria Producto
Public Class eCategoriaProducto


    Private catCodigo As Integer
    Private catDescripcion As String

    Public Sub New()
    End Sub

    Public Sub New(catCodigo As Integer, catDescripcion As String)
        pCatCodigo = catCodigo
        pCatDescripcion = catDescripcion
    End Sub

    Public Property pCatCodigo
        Get
            Return catCodigo
        End Get
        Set(ByVal value)
            If value <= 0 Then
                catCodigo = 0
            Else
                catCodigo = value
            End If

        End Set
    End Property

    Public Property pCatDescripcion
        Get
            Return catDescripcion
        End Get
        Set(ByVal value)
            catDescripcion = value
        End Set
    End Property

End Class
