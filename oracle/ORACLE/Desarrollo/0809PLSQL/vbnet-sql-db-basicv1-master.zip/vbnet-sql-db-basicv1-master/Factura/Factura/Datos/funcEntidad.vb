﻿'Clase base de las funciones que pueden realizarse en una entidad e impactar en la base de datos.
'Clase hereda conexion por lo que la funcion derivada sera capaz de conectarse gracias a su herencia.
Imports System.Data.SqlClient

Public Class funcEntidad
    Inherits Conexion

    Protected sqlSCMD As String 'String de CMD para sql
    Protected sqlSDB As String  'String de Base de Datos
    Protected cmd As New SqlCommand

    Sub New()

    End Sub

    'Nueva funcion de la entidad conectada a la base de datos especificada.
    Sub New(ByVal stringDB As String)
        sqlSDB = stringDB
    End Sub

    'Recibe un String de CMD para sql y devuelve un DataTable con la tabla.
    Public Overridable Function mostrar(sqlCMDS As String) As DataTable
        Try
            conexion(sqlSDB)
            cmd = New SqlCommand(sqlCMDS)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            If (cmd.ExecuteNonQuery) Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd) 'Encargada de la traduccion de los datos que viene de Sql
                da.Fill(dt) 'Llena dt
                Return dt
            Else
                Return Nothing 'Regresa nada
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconexion()
        End Try
    End Function

    'Recibe un String de CMD para sql y devuelve un boolean false si hay error.
    Public Overridable Function insertar(sqlCMDS As String) As Boolean
        Dim BOOL As Boolean
        Return BOOL

    End Function

    'Recibe un String de CMD para sql y devuelve un boolean.
    Public Overridable Function actualizar(sqlCMDS As String) As Boolean
        Dim BOOL As Boolean
        Return BOOL
    End Function

    'Recibe un String de CMD para sql y devuelve un boolean.
    Public Overridable Function eliminar(sqlCMDS As String, code As Integer) As Boolean
        Try
            conexion(Me.sqlSDB)
            Me.cmd = New SqlCommand(sqlCMDS)
            Me.cmd.CommandType = CommandType.StoredProcedure
            Me.cmd.Connection = conn
            cmd.Parameters.AddWithValue("@catCodigo", code)
            If (cmd.ExecuteNonQuery) Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            desconexion()
        End Try
    End Function

End Class
