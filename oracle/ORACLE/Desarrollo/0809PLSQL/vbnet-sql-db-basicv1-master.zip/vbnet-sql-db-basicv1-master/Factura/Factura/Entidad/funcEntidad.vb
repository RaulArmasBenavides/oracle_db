﻿'Clase: BASE de las funciones que pueden realizarse con una entidad e impactar en la base de datos. Dichas funciones 
'pueden o no implementarse segun sea necesario.
'Clase: hereda conexion por lo que la funcion derivada sera capaz de conectarse.
'Documentacion: los nombres de algunas variables estan en ingles, por convencion y facil traduccion
Imports System.Data.SqlClient

Public MustInherit Class funcEntidad
    Inherits Conexion
    'Declaracion de las variables +Protected+
    Protected sqlSCMD As String 'sql String Command
    Protected sqlSDB As String  'slq String Database 
    Protected cmd As New SqlCommand 'command para que se ejecute el sql

    'Nueva funcion de la entidad conectada a la base de datos especificada.
    Sub New(ByVal stringDB As String)
        sqlSDB = stringDB
    End Sub

    'Recibe un String de CMD para sql y devuelve un DataTable con la tabla.
    Overridable Function mostrar(ByVal sqlCMDS As String) As DataTable
        Try
            conexion(sqlSDB)
            cmd = New SqlCommand(sqlCMDS)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = conn
            If (cmd.ExecuteNonQuery) Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd) 'Encargada de la traduccion de los datos que viene de Sql
                da.Fill(dt) 'Llena dt
                Return dt
            Else
                Return Nothing 'Regresa nada
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconexion()
        End Try
    End Function

    'Recibe un String de CMD para sql y devuelve un boolean false si hay error.
    Overridable Function insertar(ByVal sqlCMDS As String) As Boolean
        Dim BOOL As Boolean
        Return BOOL

    End Function

    'Recibe un String de CMD para sql y devuelve un boolean.
    Overridable Function actualizar(ByVal sqlCMDS As String) As Boolean
        Dim BOOL As Boolean
        Return BOOL
    End Function

    'Recibe un String de CMD para sql y devuelve un boolean.
    'En este caso para poder eleiminar un elemento de la tabla es necesario mandar el parametro como string inclusive "@"
    Overridable Function eliminar(ByVal sqlCMDS As String, ByVal stringParam As String, ByVal code As Integer) As Boolean
        Try
            conexion(Me.sqlSDB)
            Me.cmd = New SqlCommand(sqlCMDS)
            Me.cmd.CommandType = CommandType.StoredProcedure
            Me.cmd.Connection = conn
            cmd.Parameters.Add(stringParam, SqlDbType.NVarChar, 50).Value = code
            If (cmd.ExecuteNonQuery) Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            desconexion()
        End Try
    End Function

End Class
