﻿Imports System.Data.SqlClient

'Clase encargada de manejar la conexion con la base de datos en este caso llamada **** FACTURA *******
'Hay dos maneras de iniciar la conexion con la base de datos, una es con prederminado el servidor a local.
'La otra forma de conectar la base de datos es enviando la base y servidor espicificado
Public Class Conexion

    Protected conn As New SqlConnection 'Variable conn encargada de llevar la conexion.


    Protected Function conexion(ByRef sDatabase As String) As Boolean 'Conecta a la base de datos especificada.
        Try
            Dim stringconn As String
            stringconn = "Data Source=.;" & " initial catalog=" & sDatabase & "; integrated security=true"
            Console.WriteLine(stringconn)
            conn = New SqlConnection(stringconn)
            conn.Open()
            Return True
        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        End Try
    End Function

    Protected Function conexion(ByRef sSource As String, ByRef sDatabase As String) As Boolean 'Conecta a la base y al servidor especificado
        Try
            Dim stringconn As String
            stringconn = "Data Source=" & sSource & "; initial catalog=" & sDatabase & "; integrated security=true"
            Console.WriteLine(stringconn)
            conn = New SqlConnection(stringconn)
            conn.Open()
            Return True
        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        End Try

    End Function

    Protected Function desconexion() As Boolean
        Try
            If (conn.State = ConnectionState.Open) Then
                conn.Close()
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        End Try
    End Function

End Class
