﻿'Esta clase es la encargada de hacer los objetos que contienen todas las funciones de Producto Stored Procedures
'La clase conecta .net con sql.

'Clase derivada de funcEntidad capaz de conectarse con la base de datos e impactarla.
'Las funciones se tienen que "override" para cada tipo de entidad basica de este programa.

Imports System.Data.SqlClient
Public Class fProducto
    Inherits funcEntidad

    Private producto As New eProducto
    Public Sub New(product As eProducto)
        Me.sqlSDB = "factura"
        producto = product
    End Sub


    Public Property prod

        Get
            Return producto
        End Get
        Set(value)
            producto = value
        End Set
    End Property
    Public Overrides Function mostrar(sqlCMDS As String) As DataTable
        Return MyBase.mostrar(sqlCMDS)
    End Function

    Public Overrides Function insertar(sqlCMDS As String) As Boolean 'Recibe un eProducto objeto, para acceder a los terminos a insertar
        Try

            conexion(Me.sqlSDB)
            Me.cmd = New SqlCommand(sqlCMDS)
            Me.cmd.CommandType = CommandType.StoredProcedure
            Me.cmd.Connection = conn
            Me.cmd.Parameters.AddWithValue("@proDescripcion", prod.prDescripcion)
            Me.cmd.Parameters.AddWithValue("@proPrecioCompra", prod.prPrecioCompra)
            Me.cmd.Parameters.AddWithValue("@proPrecioVenta", prod.prPrecioVenta)
            Me.cmd.Parameters.AddWithValue("@proFechaCompra", prod.prFechaCompra)
            Me.cmd.Parameters.AddWithValue("@proFechaVencimiento", producto.prFechaVencimiento)
            Me.cmd.Parameters.AddWithValue("@proExistencia", prod.prExistencia)
            Me.cmd.Parameters.AddWithValue("@proCatCodigo", prod.prCatCodigo)
            If (Me.cmd.ExecuteNonQuery) Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            desconexion()
        End Try
    End Function
End Class
