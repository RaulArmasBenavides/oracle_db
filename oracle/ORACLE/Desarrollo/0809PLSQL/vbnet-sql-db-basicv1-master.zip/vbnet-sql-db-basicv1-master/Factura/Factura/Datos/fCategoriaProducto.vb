﻿'Esta clase es la encargada de hacer los objetos que contienen todas las funciones de CategoriaProducto Stored Procedures
'La clase conecta .net con sql.

'Clase derivada de funcEntidad capaz de conectarse con la base de datos e impactarla.
'Las funciones se tienen que "override" para cada tipo de entidad basica de este programa.
Imports System.Data.SqlClient

Public Class fCategoriaProducto
    Inherits funcEntidad

    Private categoria As eCategoriaProducto

    Public Sub New()
        Me.sqlSDB = "factura"
    End Sub
    Public Sub New(category As eCategoriaProducto)
        Me.sqlSDB = "factura"
        categoria = category
    End Sub
    Public Property categ

        Get
            Return categoria
        End Get
        Set(value)
            categoria = value
        End Set
    End Property

    Public Overrides Function mostrar(sqlCMDS As String) As DataTable
        Return MyBase.mostrar(sqlCMDS)
    End Function


    'Recibe el comando para ejecutar una iserccion.
    Public Overrides Function insertar(sqlCMDS As String) As Boolean
        Try

            conexion(Me.sqlSDB)
            Me.cmd = New SqlCommand(sqlCMDS)
            Me.cmd.CommandType = CommandType.StoredProcedure
            Me.cmd.Connection = conn
            Me.cmd.Parameters.AddWithValue("@catDescripcion", categ.pCatDescripcion)
            If (Me.cmd.ExecuteNonQuery) Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            desconexion()
        End Try
    End Function

    'Recibe el comando para ejecutar la actualizacion.
    Public Overloads Function actualizar(sqlCMDS As String) As Boolean 'Actualizar con el eCategoriaProducto 
        Try
            conexion(Me.sqlSDB)
            Me.cmd = New SqlCommand(sqlCMDS)
            Me.cmd.CommandType = CommandType.StoredProcedure
            Me.cmd.Connection = conn
            cmd.Parameters.AddWithValue("@catCodigo", categ.pCatCodigo)
            cmd.Parameters.AddWithValue("@catDescripcion", categ.pCatDescripcion)
            If (cmd.ExecuteNonQuery) Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        Finally
            desconexion()
        End Try
    End Function

    Public Overrides Function eliminar(sqlCMDS As String, code As Integer) As Boolean
        Return MyBase.eliminar(sqlCMDS, code)
    End Function


End Class
