![ORACLE PL-SQL](https://raw.githubusercontent.com/gcoronelc/PLSQL-2019-08/master/img/plsql.png)


# TALLER DE ORACLE PL-SQL

## DATOS GENERALES

- Lugar: SistemasUNI
- Horario: DOMINGO DE 15 A 21 HORAS
- Inicio: 24.AGO.2019
- Dirección: https://goo.gl/maps/98vwAt9NZMU2
- Página: https://github.com/gcoronelc/PLSQL-2019-08
- Código fuente: https://goo.gl/GRaOQg
- Youtube: https://www.youtube.com/c/DesarrollaSoftware
- Videos: https://bit.ly/2CgwpwM

## DOCENTE

- Docente: Eric Gustavo Coronel Castillo
- Blog: www.desarrollasoftware.com
- Canal Youtube: https://bit.ly/2BWvikz
- Facebook 1: https://www.facebook.com/groups/universidadjava/
- Facebook 2: https://www.facebook.com/groups/desarrollasoftware/
- Facebook 3: https://www.facebook.com/groups/bolsa.sistemas/

## TALLERES ANTERIORES

- PLSQL JULIO-2018: http://gcoronelc.blogspot.com/2018/08/taller-plsql.html
- JAVA WEB: http://gcoronelc.blogspot.com/2018/08/taller-de-java-web.html

# CURSOS VIRTUALES


## JAVA ORIENTADO A OBJETOS

URL: https://bit.ly/2B3ixUW

[![JAVA ORIENTADO A OBJETOS](http://img.youtube.com/vi/EKlwF12-l9Y/0.jpg)](http://www.youtube.com/watch?v=EKlwF12-l9Y "JAVA ORIENTADO A OBJETOS")

## PROGRAMACIÓN DE BASE DE DATOS ORACLE CON JAVA JDBC

URL: https://bit.ly/31apy0O

[![JAVA JDBC CON BASE DE DATOS ORACLE](http://img.youtube.com/vi/MR53Xgeg28Y/0.jpg)](http://www.youtube.com/watch?v=MR53Xgeg28Y "JAVA JDBC CON BASE DE DATOS ORACLE")



# OTROS ELEMENTOS

## RECURSOS RECOMENDADOS

- Bases de Datos Ejemplo: https://github.com/gcoronelc/databases
- Práctica de Oracle SQL: http://gcoronelc.blogspot.pe/2017/11/practica-de-oracle-sql.html
- Conexión con JDBC: http://gcoronelc.blogspot.pe/2017/11/jdbc-conexion-con-bases-de-datos.html
- Manejo de ResultSet: http://gcoronelc.blogspot.pe/2015/01/java-jdbc-resultset-to-list.html
- Consultas Básicas: http://gcoronelc.blogspot.pe/2014/11/oracle-sql-consultas-basicas.html
- Introducción a SQL: http://gcoronelc.blogspot.pe/2014/11/oracle-sql-introduccion.html
- Creación del esquema EUREKA: http://gcoronelc.blogspot.pe/2014/11/creacion-del-esquema-eureka.html
- Cursores con JDBC: http://gcoronelc.blogspot.pe/2014/05/java-jdbc-oracle-cursor.html
- PL/SQL Language Reference: https://docs.oracle.com/cd/B28359_01/appdev.111/b28370/toc.htm
- Instalación de Oracle XE 11g R2: https://youtu.be/oQ5RTubYrUI

## APLICACIONES JAVA CON BASE DE DATOS EUREKA 

- Eureka App: http://gcoronelc.blogspot.pe/2016/10/eureka-cs-oracle-jdbc.html
- Eureka Web: http://gcoronelc.blogspot.com/2016/12/eureka-web-oracle-jdbc.html
- Eurwka Spring: http://gcoronelc.blogspot.com/2017/07/eureka-web-mysql-spring.html

